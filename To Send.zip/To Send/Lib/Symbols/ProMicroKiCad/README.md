Pro Micro library for KiCAD
=======================================

This repo includes Pro Micro library.

### Variants
* ProMicro.kicad_mod - The default variant
* ProMicro-NoSilk.kicad_mod - No silkscreen guides
* ProMicro-EnforcedTop.kicad_mod - Covers the Pro Micro side of all pads with soldermask to make reverse-side mounting impossible.
